package com.example.practica32.ui.aves;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class avesViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public avesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is aves fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
